import boto3

region = 'us-east-1'
ec2 = boto3.client('ec2', region_name=region)
rds = boto3.client('rds', region_name=region)

def get_instances_to_manage():
    ec2_response = ec2.describe_instances(Filters=[
        {'Name': 'tag:Auto-Start', 'Values': ['true']}
    ])
    
    ec2_instances = []
    for reservation in ec2_response["Reservations"]:
        for instance in reservation["Instances"]:
            ec2_instances.append(instance["InstanceId"])
    
    rds_response = rds.describe_db_instances()
    rds_instances = []
    
    for db_instance in rds_response['DBInstances']:
        tags = rds.list_tags_for_resource(
            ResourceName=db_instance['DBInstanceArn']
        )['TagList']
        
        if any(tag['Key'] == 'Auto-Start' and tag['Value'] == 'true' for tag in tags):
            rds_instances.append(db_instance['DBInstanceIdentifier'])
    
    return ec2_instances, rds_instances

def stop(event, context):
    ec2_instances, rds_instances = get_instances_to_manage()
    
    if ec2_instances:
        ec2.stop_instances(InstanceIds=ec2_instances)
        print(f'Stopped EC2 instances: {ec2_instances}')
    
    for rds_instance in rds_instances:
        try:
            rds.stop_db_instance(DBInstanceIdentifier=rds_instance)
            print(f'Stopped RDS instance: {rds_instance}')
        except rds.exceptions.InvalidDBInstanceStateFault as e:
            print(f'Error stopping {rds_instance}: {str(e)}')

def start(event, context):
    ec2_instances, rds_instances = get_instances_to_manage()
    
    if ec2_instances:
        ec2.start_instances(InstanceIds=ec2_instances)
        print(f'Started EC2 instances: {ec2_instances}')
    
    for rds_instance in rds_instances:
        try:
            rds.start_db_instance(DBInstanceIdentifier=rds_instance)
            print(f'Started RDS instance: {rds_instance}')
        except rds.exceptions.InvalidDBInstanceStateFault as e:
            print(f'Error starting {rds_instance}: {str(e)}')